# 阅窗本地助手：安装与使用

状态：首版试验功能。脚本、构建和模拟测试通过不代表账号已取得 ChatGPT 套餐用量授权；真实登录、模型调用与关闭官网后的聊天需要分别验收。

## 它会安装什么

仅支持 Windows 当前用户与 Chrome。助手由 Chrome 按需启动；不用管理员权限、Windows 服务、开机启动项或托盘程序。登录期间会临时监听 `127.0.0.1`，结束或超时后关闭。

安装位置：

```text
%LOCALAPPDATA%\YuechuangHelper\
  com.yuechuang.helper.json          Chrome 的本地程序清单
  bin\yuechuang-helper.exe          助手程序
  bin\helper-config.json            允许连接的阅窗扩展来源
  credentials.bin                   助手生成的加密凭证（登录后才有）
```

安装脚本写入且仅写入这一项当前用户注册表：

```text
HKCU\Software\Google\Chrome\NativeMessagingHosts\com.yuechuang.helper
```

助手配置只允许指定的一个扩展 ID。加载不同路径的未打包插件可能得到不同 ID，需要用新 ID 再运行安装脚本。安装包不包含账号凭证；安装也不会自动打开登录页面。

## 安装

1. 先在 Chrome 扩展管理页加载或重新加载阅窗，打开侧栏「设置」，选择「ChatGPT 订阅（官方登录）」。在助手安装说明中点击「复制 ID」取得当前插件的真实扩展 ID；也可以在 `chrome://extensions` 中找到阅窗并复制 ID。格式是 32 个小写字母，取值范围为 `a` 到 `p`。
2. 解压本地助手包，在解压目录打开 PowerShell。
3. 执行以下命令，把示例 ID 替换为阅窗的实际 ID。使用开发源码时，在项目根目录执行，并把脚本路径写成 `.\scripts\helper-install.ps1`。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\helper-install.ps1 -ExtensionId 实际扩展ID
```

这条命令只对本次 PowerShell 进程放行脚本执行，不修改系统的执行策略。如果希望先查看目标位置与来源限制，加上 `-DryRun`；它只验证和打印方案，不创建文件、不写注册表。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\helper-install.ps1 -ExtensionId 实际扩展ID -DryRun
```

安装后，在 Chrome 扩展管理页重新加载阅窗，再从侧栏设置进入 ChatGPT 订阅登录。登录时完成 OpenAI 页面上的身份验证与套餐用量授权；只完成身份登录时，插件不应显示为可以使用订阅聊天。

首次授权完成后，关闭所有 ChatGPT 标签页，在阅窗侧栏选择账号允许的模型并发送问题。聊天请求直接发给 OpenAI，助手只处理本应用的授权凭证。遇到登录过期时，再从侧栏重新授权。

## 更新与卸载

更新助手前先关闭阅窗侧栏，完成或取消正在进行的登录，再运行新包中的安装脚本。它会保留加密凭证。程序正在运行、目标位置含链接跳转，或注册表指向另一安装位置时，脚本会停止，不会强制终止进程或覆盖其他安装。

卸载默认保留加密凭证，方便重装：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\helper-uninstall.ps1
```

同时删除本地凭证：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\helper-uninstall.ps1 -RemoveCredentials
```

卸载脚本只逐个删除本应用已知文件和对应注册表项；其他文件会保留。`-DryRun` 同样可以预览。删除凭证文件不会自动撤销 OpenAI 端授权；需要退出授权时，先使用阅窗的退出功能，并查看远程撤销结果。

## 开发者构建与离线检查

需要已安装的 Go 工具链；运行成品 EXE 不需要 Go、Node.js 或 Python。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\helper-build.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\helper-smoke.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\helper-package.ps1 -SkipBuild
```

构建默认先运行 Go 测试，关闭依赖下载并使用项目 `helper\.gocache` 与 `helper\.gotmp` 目录；不读取其他应用凭证。输出为 `helper\bin\yuechuang-helper.exe`。打包将 EXE、安装/卸载脚本、说明和文件校验值放入 `helper-release` 的新目录与 ZIP，保留历史包，并复制为当前版本的稳定交付路径 `release\yuechuang-helper-<版本号>.zip`；开发源码和缓存不进入包。

脚本烟测只使用工作区内的临时假 EXE 测试方案生成、扩展 ID 校验、路径边界与卸载选项；它不会安装助手、写注册表、读取凭证、联网或发起登录。

## 首次验收

- 安装后侧栏识别助手；未安装时给出清楚提示。
- 登录后分别确认账号身份与套餐用量权限。
- 关闭全部 ChatGPT 标签页后列出可用模型并收到一条完整回答。
- 操作结束后，任务管理器中没有残留 `yuechuang-helper.exe`；再次使用时 Chrome 自动启动助手。
- 退出与卸载的结果清楚，拒绝授权、凭证失效和额度不足分别提示。

不要把 `credentials.bin`、访问令牌或授权回调链接粘贴到诊断消息中。
